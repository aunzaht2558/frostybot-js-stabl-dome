frostybot_exchange_ftx = require('./exchange.ftx');

module.exports = class frostybot_exchange_ftxus extends frostybot_exchange_ftx {

    // Class constructor

    constructor(stub) {
        super(stub);
    }



}
